var r = Math.floor(9*Math.random() + 1);
document.getElementById("qoter").src = "media/img/quote" + r + ".png";
document.getElementById("qoter").alt = "quote" + r;